from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders 
import schedule 
import time
import cx_Oracle
import smtplib
import csv

#DEFININDO TIMER PARA EXECUÇÃO AUTOMATICA DO SCRIPT
#def script():

#-------------------------------------------------------CONECTANDO COM A BANCO ORACLE-----------------------------------------
#CONECTANDO NO BANCO
con = cx_Oracle.connect("br0751366781/enel2019@x1-scan:1521/operhml.celg.go")
cursor = con.cursor()

#GERANDO O ARQUIVO CSV 
csv_file = open("operacao_usuario.csv", "w")

#ESTRUTURANDO O ARQUIVO E EXECUTANDO SQL
writer = csv.writer(csv_file, delimiter=';', lineterminator="\n", quoting=csv.QUOTE_NONNUMERIC)
r = "select 'B' as tipo_record, SYSDATE	data, 'G2M OPER+ Goais Brazil'  cod_applicazion, usu_matricula cod_utente, null DESC_UTENTE, DECODE(usu_status,1,'U',2,'L')stato_utente, null COD_INS_PROFILO, perfil_id profilo, 'B' cod_profilo, null DATA_ATT_PROFILO, null DESC_PROFILO, null NOTE, null ESITO_CARICAMENTO, null CONSUMATO from OPERACAO.usuario WHERE usu_matricula IS NOT NULL"
cursor.execute(r)

#NOME DA TABELA
col_names = [row[0] for row in cursor.description]
writer.writerow(col_names)

#GRAVANDO INFORMAÇÕES DA TABELA
for row in cursor:
	writer.writerow(row)
   
cursor.close()
con.close()
csv_file.close()

print('Exportação Concluída !')

#----------------------------------------------------CONECTANDO COM SMTP E ENVIANDO E-MAIL-----------------------------------

msg = MIMEMultipart()

msg["Subject"] = "Example"
msg["From"] = "victor.marques@enel.com"
msg["To"] = "victor.hugomarques@hotmail.com"
msg["Cc"] = "victor.marques@enel.com"

#msg['From'] = email_user
#msg['To'] = email_send 
#msg['Cc'] = cc
#msg['Subject'] = subject

print ('Enviando E-mail...\n')

body = 'Teste E-mail'
msg.attach(MIMEText(body,'plain'))

filename='operacao_usuario.csv'
attachment  = open(filename,'rb')

part = MIMEBase('application' , 'octet-stream')
part.set_payload((attachment).read())
encoders.encode_base64(part)
part.add_header('Content-Disposition' , "attachment; filename = " + filename)

msg.attach(part)
text = msg.as_string()
#UTILIZANDO SERVIDOR SEGURO - GDS (NAO PRECISA DE AUTENTIFICAÇÃO, LOGO DEVEMOS RETIRAR ALGUMAS SCRIPTS DA BIBLIOTECA SMTPLIB)
server = smtplib.SMTP("relaylatam.endesa.es" , 25)
#server = smtplib.SMTP("smtp-mail.outlook.com",587)
#server.starttls()
#server.login(email_user,email_password)

server.sendmail(msg["From"], msg["To"].split(",") + msg["Cc"].split(",") , text)



print ('E-mail enviado!')

server.quit()

#DEFINE INTERVALO DE TEMPO DE EXECUÇÃO DO SCRIPT
#schedule.every(15).seconds.do(teste)
#schedule.every().monday.at("11:34").do(script)


#LOOP
#hile 1:
	#schedule.run_pending()
	#time.sleep(1)
